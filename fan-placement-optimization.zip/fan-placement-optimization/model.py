import numpy as np

WIDTH, DEPTH = 21.0, 32.0
H_FRONT, H_REAR, Y_TAPER, TAPER_SLOPE = 8.0, 5.18, 6.35, 0.11
AISLE, SETBACK, SEAT_FILL = 1.63, 2.1, 0.78
BLOCKS = [(6.35, 9.35), (10.99, 14.99), (17.62, 25.62)]
CMAX, REACH, EXPONENT = 4.0, 3.5, 1.5

R = 1 / np.sqrt(2)
UNOPTIMIZED = [(0.0, 0.0, np.pi / 4), (0.0, 21.0, -np.pi / 4)]


def ceiling_height(y):
    y = np.asarray(y, dtype=float)
    return np.maximum(np.where(y <= Y_TAPER, H_FRONT, H_FRONT - TAPER_SLOPE * (y - Y_TAPER)), H_REAR)


def design_matrix(x, y):
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    return np.column_stack([np.ones_like(x), 1 - x / WIDTH, 1 / ceiling_height(y) - 1 / H_FRONT])


def fit_surface(x, y, t):
    A = design_matrix(x, y)
    coefs = np.linalg.lstsq(A, t, rcond=None)[0]
    resid = t - A @ coefs
    r2 = 1 - (resid ** 2).sum() / ((t - t.mean()) ** 2).sum()
    return coefs, r2


def ambient(x, y, coefs):
    return design_matrix(np.ravel(x), np.ravel(y)) @ coefs


def seat_points(n=60):
    col = (WIDTH - AISLE) / 2 * SEAT_FILL
    cols = [(SETBACK, SETBACK + col), (WIDTH - SETBACK - col, WIDTH - SETBACK)]
    xs = np.concatenate([np.linspace(a, b, n) for a, b in cols])
    ys = np.concatenate([np.linspace(a, b, n) for a, b in BLOCKS])
    X, Y = np.meshgrid(xs, ys)
    return X.ravel(), Y.ravel()


def fan_cooling(x, y, fan, strength=1.0):
    fx, fy, ang = fan
    dx, dy = x - fx, y - fy
    d = np.hypot(dx, dy) + 1e-6
    gate = np.clip((np.cos(ang) * dx + np.sin(ang) * dy) / d, 0, None)
    drop = CMAX / (1 + (d / REACH) ** 2) * gate ** EXPONENT
    return strength * np.minimum(CMAX, drop)


def net_temperature(x, y, fans, coefs, strength=1.0):
    t = ambient(x, y, coefs)
    if not fans:
        return t
    cooling = np.max([fan_cooling(np.ravel(x), np.ravel(y), f, strength) for f in fans], axis=0)
    return t - cooling


def seat_stats(fans, coefs, strength=1.0, pts=None):
    x, y = pts if pts is not None else seat_points()
    t = net_temperature(x, y, fans, coefs, strength)
    return t.max() - t.min(), t.max(), t.min()
