# Fan Placement Optimization for a Tiered Lecture Hall

Two fans cannot cool a hall evenly if they are placed by guesswork. This project measures the hall's temperature, fits a smooth surface to it, models what a fan does to the seats around it, and searches for the fan positions and directions that make the seat temperatures as even as possible.

![Temperature maps](results/temperature_maps.png)

## Method

1. **Measure.** Ten fans-off readings across the 21 m x 32 m hall (`data/baseline_measurements.csv`).
2. **Fit.** Least squares on `T(x, y) = c0 + c1 (1 - x/21) + c2 (1/h(y) - 1/8)`, where `h(y)` is the ceiling height (8.0 m at the front, tapering to 5.18 m at the rear).
3. **Model the fans.** Each fan cools by `Cmax / (1 + (d / reach)^2)` times a directional gate `max(0, cos)^1.5`, capped at `Cmax = 4.0` C. Where both fans reach a seat, the stronger one is used.
4. **Optimize.** Minimize `J = hottest seat - coolest seat` over the three seating blocks with SciPy's differential evolution.

## Run

```
pip install -r requirements.txt
python run.py
```

Output is written to `results/`: `summary.txt`, `results.json`, `temperature_maps.png`, `seat_gap_comparison.png`, and `fan_placement_animation.gif`.

## Results

| Scenario | J (C) | Hottest seat (C) | Coolest seat (C) |
|---|---|---|---|
| No fans | 2.73 | 22.93 | 20.19 |
| Unoptimized placement | 2.94 | 22.88 | 19.93 |
| Optimized, West wall aimed East | 2.01 | 21.83 | 19.82 |
| Optimized, free position and aim | 1.58 | 21.72 | 20.14 |

- The surface fit reproduces the measurements with R^2 = 0.9997.
- `dT/dx = -0.095 C/m`: temperature falls from West to East.
- `dT/dy = 2.77 / h(y)^2 C/m` for y > 6.35 m: temperature rises toward the rear as the ceiling drops.
- Fans placed close to the seats overcool the seats next to them and widen the gap.
- Mounted on the West wall and aimed East, the same two fans cut the gap about 26% from the no-fan case.

![Seat gap comparison](results/seat_gap_comparison.png)

## Files

| File | Purpose |
|---|---|
| `model.py` | Geometry, surface fit, fan cooling model, seat grid |
| `run.py` | Fit, optimization, tables, figures, animation |
| `data/baseline_measurements.csv` | The ten fans-off measurements |

Hall geometry, seat blocks, `Cmax`, reach, and exponent are constants at the top of `model.py`.
