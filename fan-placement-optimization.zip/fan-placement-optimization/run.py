import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle
from scipy.optimize import differential_evolution
import model as m

N = 60
data = np.genfromtxt("data/baseline_measurements.csv", delimiter=",", skip_header=1, usecols=(1, 2, 3))
coefs, r2 = m.fit_surface(data[:, 0], data[:, 1], data[:, 2])
pts = m.seat_points(N)


def stats(fans, s=1.0):
    return m.seat_stats(fans, coefs, s, pts)


def optimize(objective, bounds):
    r = differential_evolution(objective, bounds, seed=0, maxiter=300, popsize=25, tol=1e-10, polish=False)
    return r.x


wall = optimize(lambda v: stats([(0, v[0], 0), (0, v[1], 0)])[0], [(0, m.DEPTH)] * 2)
free = optimize(lambda v: stats([(v[0], v[1], v[2]), (v[3], v[4], v[5])])[0],
                [(0, m.WIDTH), (0, m.DEPTH), (-np.pi, np.pi)] * 2)

scenarios = {
    "No fans": [],
    "Unoptimized": m.UNOPTIMIZED,
    "Optimized (West wall, aimed East)": [(0.0, wall[0], 0.0), (0.0, wall[1], 0.0)],
    "Optimized (free position and aim)": [(free[0], free[1], free[2]), (free[3], free[4], free[5])],
}
rows = {k: dict(zip(("J", "high", "low"), map(float, stats(f)))) for k, f in scenarios.items()}
for k, f in scenarios.items():
    rows[k]["fans"] = [dict(x=round(a, 2), y=round(b, 2), aim_deg=round(float(np.degrees(c)), 1)) for a, b, c in f]
base = rows["No fans"]["J"]
for k in rows:
    rows[k]["change_vs_no_fans_pct"] = round(100 * (1 - rows[k]["J"] / base), 1)

grad_x, grad_y_coef = -coefs[1] / m.WIDTH, coefs[2] * m.TAPER_SLOPE
out = dict(
    surface=dict(c0=round(coefs[0], 3), c1=round(coefs[1], 3), c2=round(coefs[2], 3), r2=round(r2, 4),
                 dT_dx=round(grad_x, 3), dT_dy_numerator=round(grad_y_coef, 3)),
    scenarios=rows,
)
json.dump(out, open("results/results.json", "w"), indent=2)

lines = [f"Surface fit: T(x,y) = {coefs[0]:.2f} + {coefs[1]:.2f}(1 - x/21) + {coefs[2]:.2f}(1/h(y) - 1/8)   R2 = {r2:.4f}",
         f"dT/dx = {grad_x:.3f} C/m    dT/dy = {grad_y_coef:.2f}/h(y)^2 C/m (y > {m.Y_TAPER} m)", "",
         f"{'Scenario':36s}{'J (C)':>8s}{'High':>8s}{'Low':>8s}{'vs no fans':>12s}"]
for k, v in rows.items():
    lines.append(f"{k:36s}{v['J']:8.2f}{v['high']:8.2f}{v['low']:8.2f}{v['change_vs_no_fans_pct']:11.1f}%")
lines += ["", "Fan positions (x m, y m, aim deg):"]
for k, v in rows.items():
    if v["fans"]:
        lines.append(f"  {k}: " + "; ".join(f"({f['x']}, {f['y']}, {f['aim_deg']})" for f in v["fans"]))
open("results/summary.txt", "w").write("\n".join(lines) + "\n")
print("\n".join(lines))

gx, gy = np.meshgrid(np.linspace(0, m.WIDTH, 140), np.linspace(0, m.DEPTH, 200))
col = (m.WIDTH - m.AISLE) / 2 * m.SEAT_FILL
cols = [(m.SETBACK, m.SETBACK + col), (m.WIDTH - m.SETBACK - col, m.WIDTH - m.SETBACK)]
vmin = m.ambient(gx, gy, coefs).min() - m.CMAX
vmax = m.ambient(gx, gy, coefs).max()
levels = np.linspace(vmin, vmax, 18)


def draw(ax, fans, s, title):
    ax.clear()
    t = m.net_temperature(gx, gy, fans, coefs, s).reshape(gx.shape)
    ax.contourf(gx, gy, t, levels=levels, cmap="RdYlBu_r")
    for a, b in m.BLOCKS:
        for c0, c1 in cols:
            ax.add_patch(Rectangle((c0, a), c1 - c0, b - a, fill=False, ec="black", lw=1))
    for fx, fy, ang in fans:
        ax.plot(fx, fy, "o", mfc="white", mec="black", ms=9, zorder=5)
        ax.arrow(fx, fy, 2.5 * np.cos(ang), 2.5 * np.sin(ang), head_width=0.6, color="black", zorder=5)
    j, hi, lo = stats(fans, s)
    ax.set_title(f"{title}\nJ = {j:.2f} C   High {hi:.1f} C   Low {lo:.1f} C", fontsize=10)
    ax.set_xlim(0, m.WIDTH)
    ax.set_ylim(0, m.DEPTH)
    ax.invert_yaxis()
    ax.set_xlabel("x (m, West to East)")


fig, axes = plt.subplots(1, 3, figsize=(14, 6.5))
for ax, k in zip(axes, ["No fans", "Unoptimized", "Optimized (West wall, aimed East)"]):
    draw(ax, scenarios[k], 1.0, k)
axes[0].set_ylabel("y (m, front to rear)")
fig.tight_layout()
fig.savefig("results/temperature_maps.png", dpi=150)
plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 4.5))
names = list(rows)
vals = [rows[k]["J"] for k in names]
bars = ax.bar(range(4), vals, color=["#17454f", "#f15a2b", "#1f7a5c", "#5a8fd0"])
for i, k in enumerate(names):
    ax.text(i, vals[i] + 0.04, f"{vals[i]:.2f}\n{rows[k]['high']:.1f} / {rows[k]['low']:.1f}", ha="center", fontsize=9)
ax.set_xticks(range(4))
ax.set_xticklabels([n.replace(" (", "\n(") for n in names], fontsize=8)
ax.set_ylabel("J = hottest seat - coolest seat (C)")
ax.set_ylim(0, max(vals) * 1.25)
ax.set_title("Seat temperature gap (labels: J, then high / low in C)")
fig.tight_layout()
fig.savefig("results/seat_gap_comparison.png", dpi=150)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(11, 6.3))
pair = [("Unoptimized", scenarios["Unoptimized"]), ("Optimized (West wall, aimed East)", scenarios["Optimized (West wall, aimed East)"])]
frames = 60


def step(i):
    s = min(1.0, i / (frames * 0.7))
    for ax, (k, f) in zip(axes, pair):
        draw(ax, f, s, f"{k}\nFan power {s * 100:3.0f}%")
        t = ax.get_title().split("\n")
        ax.set_title(f"{t[0]}  |  {t[1]}\n{t[2]}", fontsize=9)
    axes[0].set_ylabel("y (m, front to rear)")
    fig.tight_layout()


animation.FuncAnimation(fig, step, frames=frames, interval=80).save("results/fan_placement_animation.gif",
                                                                      writer=animation.PillowWriter(fps=12))
print("Saved results/")
